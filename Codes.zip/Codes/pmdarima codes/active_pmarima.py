import pmdarima as pm
from pmdarima.model_selection import train_test_split
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA

df =  pd.read_excel("D:\FCG2.xlsx")
df['Date']=pd.to_datetime(df['Date'])
result_Active = df.groupby('Date')['Active'].sum().reset_index()
result_Active.set_index("Date",inplace=True)

result_Active.plot()

y = result_Active
train, test = train_test_split(y, train_size=150)

model = pm.auto_arima(train, seasonal=False, m=12)

forecasts = model.predict(test.shape[0])

x = np.arange(y.shape[0])
plt.plot(x[:150], train, c='blue')
plt.plot(x[150:], forecasts, c='green')
plt.show()

